// test/config.js
module.exports = {
  baseURL: process.env.BASE_URL || 'https://n8n.cap.random-generator.pro/webhook/6e6ed2ed-570e-4c1f-83e2-93f442338621'
};
